import styled from "styled-components"

export const MyButton=styled.button({
    width:'200px',height:'100px',border:'4px solid blue',color:'red',textTransform:'uppercase'
})

//regular css format
export const MyTextBox=styled.input`
color:red;background-color:aqua

`