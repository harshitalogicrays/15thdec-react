// function FirstFuncomp(){
//     return <h1>functional component</h1>
// }
// export default FirstFuncomp

// let FirstFuncomp= function (){
//     return <h1>functional component</h1>
// }
// export default FirstFuncomp

// let FirstFuncomp=()=>{
//     return <h1>functional component</h1>
// }
// export default FirstFuncomp

import React from 'react'

const FirstFuncomp = () => {
  return (
    <div>
         <h1>functional component</h1>
    </div>
  )
}

export default FirstFuncomp
