import React from 'react'

const Pagenotfound = () => {
  return (
   <h1 className='text-danger'>404 Not Found</h1>
  )
}

export default Pagenotfound
